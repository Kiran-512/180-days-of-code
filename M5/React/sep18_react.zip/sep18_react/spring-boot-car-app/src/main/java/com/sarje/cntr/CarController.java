package com.sarje.cntr;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.sarje.entity.Car;
import com.sarje.service.CarService;

@RestController
@CrossOrigin("http://localhost:3000/")
public class CarController {

	@Autowired
	private CarService carService;
	
	@Autowired
	private ServletContext servletContext;
	
	
	@PostMapping("/car")
	public String carAdd(@RequestBody Car car) {
		carService.add(car);
		return "success";
	}
	
	@GetMapping("/car")
	public List<Car> carList(){
		return carService.selectAll();
	}
	
	@DeleteMapping("/car/{id}")
	public String carDelete(@PathVariable int id) {
		carService.remove(id);
		return "success";
	}
	
	@PutMapping("/car")
	public String carUpdate(@RequestBody Car car) {
		carService.modify(car);
		return "success";
	}
	
	@PostMapping("/car/upload/{id}")
	public String carUpload(@PathVariable int id, @RequestParam MultipartFile carImage) {
		
		String fileName = carImage.getOriginalFilename();
		
		fileName = fileName.substring(fileName.lastIndexOf("."));
		
		fileName = id+fileName;
		
		String filePath = servletContext.getRealPath("/images");
		
		Path path = Paths.get(filePath);
		if(!Files.exists(path)) {
			try {
				Files.createDirectory(path);
						
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		path = path.resolve(path+"/"+fileName);
		
		System.out.println("path============"+path.toString());
		
		try {
			Files.copy(carImage.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
			
			
			Car car = carService.get(id);
			car.setImage(fileName);
			carService.modify(car);
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return "success";
	}
	
}
