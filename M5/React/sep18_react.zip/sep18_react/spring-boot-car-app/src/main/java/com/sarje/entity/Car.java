package com.sarje.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "car")
@Data
public class Car {
	@Id
	@GeneratedValue
	@Setter
	@Getter
	private int id;
	@Setter
	@Getter
	private String model;
	@Setter
	@Getter
	private float price;
	@Setter
	@Getter
	private String year;
	@Setter
	@Getter
	private String make;
	@Setter
	@Getter
	private String image;
	
	
}
