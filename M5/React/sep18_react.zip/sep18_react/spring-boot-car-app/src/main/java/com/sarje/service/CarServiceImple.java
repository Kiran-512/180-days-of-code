package com.sarje.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sarje.dao.CarDao;
import com.sarje.entity.Car;

@Service
public class CarServiceImple implements CarService {
	
	@Autowired
	private CarDao carDao;

	@Override
	public void add(Car car) {
		carDao.save(car);
	}

	@Override
	public List<Car> selectAll() {
		Iterable<Car> it = carDao.findAll();
		List<Car> lst = new ArrayList<>();
		Iterator<Car> itr = it.iterator();
		while(itr.hasNext()) {
			lst.add(itr.next());
		}
		return lst;
	}

	@Override
	public void remove(int id) {
		carDao.deleteById(id);
	}

	@Override
	public void modify(Car car) {
		carDao.save(car);
	}

	@Override
	public Car get(int id) {
		Optional<Car> ref = carDao.findById(id);
		Car car = ref.get();
		return car; 
	}

	
}
