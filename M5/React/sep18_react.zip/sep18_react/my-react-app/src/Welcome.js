function Welcome(){
  return <h1>Car App</h1>;
};
export default Welcome;